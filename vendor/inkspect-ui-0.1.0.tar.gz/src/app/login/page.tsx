export { LoginPage as default } from "../../self-hosted/auth-pages";
