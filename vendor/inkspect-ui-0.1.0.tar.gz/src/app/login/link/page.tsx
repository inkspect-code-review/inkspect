export { AccountLinkPage as default } from "../../../self-hosted/auth-pages";
