export { TwoFactorPage as default } from "../../../self-hosted/auth-pages";
