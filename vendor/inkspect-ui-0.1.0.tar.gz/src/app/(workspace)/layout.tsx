export { WorkspaceLayout as default } from "../../self-hosted/workspace-pages";
