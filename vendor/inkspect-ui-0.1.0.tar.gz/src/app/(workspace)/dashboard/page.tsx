export { DashboardPage as default } from "../../../self-hosted/workspace-pages";
export const metadata = { title: "Workspace · Inkspect" };
