export { OnboardingPage as default } from "../../../self-hosted/workspace-pages";
export const metadata = { title: "Set up your workspace · Inkspect" };
