export { InvitePage as default } from "../../self-hosted/auth-pages";
