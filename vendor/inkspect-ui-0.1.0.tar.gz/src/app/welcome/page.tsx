export { WelcomePage as default } from "../../self-hosted/auth-pages";
